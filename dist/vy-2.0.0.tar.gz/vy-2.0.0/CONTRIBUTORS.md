Contributors
============

I'll list the people who contributed with vy by giving tips, testing, finding bugs and odd behaviors.

###Victor Westmann

Tested vy on windows and found an inconsistency with vy installation on windows platforms.
He also has improved the quality of the project LOGO.

**Github:**
https://github.com/victorwestmann?tab=repositories

