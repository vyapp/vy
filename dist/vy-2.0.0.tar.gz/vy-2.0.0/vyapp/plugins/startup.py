from untwisted.tkinter import extern
from vyapp.app import root

extern(root)

