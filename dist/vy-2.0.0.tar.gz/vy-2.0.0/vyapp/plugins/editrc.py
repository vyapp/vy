"""

"""
from vyapp.app import root

def install(area):
    area.install(('ALPHA', '<Key-v>', lambda event: event.widget.load_data(root.rc)))


